#pragma once
#include<glm/glm.hpp>

using glm::vec3;
using color = glm::vec3;
